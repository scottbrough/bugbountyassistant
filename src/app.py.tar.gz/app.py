#!/usr/bin/env python3
"""
Bug Bounty Assistant Web Application Backend
Professional web interface for the Enhanced Bug Bounty Assistant v3
"""

from flask import Flask, render_template, request, jsonify, send_file, session, Response
from flask_cors import CORS
from flask_socketio import SocketIO, emit
import os
import sys
import json
import threading
import queue
import time
from datetime import datetime, timedelta
from pathlib import Path
import subprocess
import logging
from typing import Dict, List, Optional, Tuple
import sqlite3

# Add src directory to path (robust for any working directory)
sys.path.append(str(Path(__file__).resolve().parent.parent / "src"))

# Import v3 modules
from advanced_assistant_v3 import EnhancedBugBountyAssistantV3
from revenue_maximizer import RevenueMaximizer
from continuous_monitor import ContinuousMonitor
from platform_integration import PlatformIntegration

app = Flask(__name__)
app.config['SECRET_KEY'] = os.environ.get('FLASK_SECRET_KEY', 'dev-secret-key-change-in-production')
CORS(app)
socketio = SocketIO(app, cors_allowed_origins="*")

# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

# Global instances
assistant = None
revenue_maximizer = RevenueMaximizer()
continuous_monitor = ContinuousMonitor()
platform_integration = None

# Hunt progress tracking
active_hunts = {}
hunt_queues = {}

class HuntProgress:
    """Track hunt progress for real-time updates"""
    def __init__(self, hunt_id: str):
        self.hunt_id = hunt_id
        self.status = "initializing"
        self.phase = "setup"
        self.progress = 0
        self.findings = []
        self.logs = []
        self.start_time = datetime.now()
        self.workspace = None
        
    def update(self, phase: str, progress: int, message: str):
        self.phase = phase
        self.progress = progress
        self.logs.append({
            'timestamp': datetime.now().isoformat(),
            'phase': phase,
            'message': message
        })
        
        # Emit update via WebSocket
        socketio.emit('hunt_progress', {
            'hunt_id': self.hunt_id,
            'phase': phase,
            'progress': progress,
            'message': message
        })

# API Routes

@app.route('/')
def index():
    """Serve the main web interface as a static file"""
    return app.send_static_file('index.html')

@app.route('/api/dashboard')
def dashboard_data():
    """Get dashboard overview data"""
    try:
        # Get earnings analytics
        analytics = revenue_maximizer.get_earnings_analytics()
        
        # Get recent changes from monitor
        recent_changes = continuous_monitor.get_recent_changes(24)
        
        # Get active hunts
        active_hunt_count = len(active_hunts)
        
        # Get recent findings from database
        conn = sqlite3.connect(revenue_maximizer.db_path)
        cursor = conn.cursor()
        
        cursor.execute("""
            SELECT COUNT(*) FROM earnings WHERE date_submitted > date('now', '-7 days')
        """)
        weekly_submissions = cursor.fetchone()[0]
        
        cursor.execute("""
            SELECT COUNT(*) FROM earnings WHERE date_submitted > date('now', '-30 days')
        """)
        monthly_submissions = cursor.fetchone()[0]
        
        conn.close()
        
        return jsonify({
            'success': True,
            'data': {
                'total_earnings': analytics['total_earnings'],
                'hourly_rate': analytics['hourly_rate'],
                'success_rate': analytics['success_rate'],
                'weekly_submissions': weekly_submissions,
                'monthly_submissions': monthly_submissions,
                'active_hunts': active_hunt_count,
                'recent_changes': len(recent_changes),
                'top_earning_types': analytics['earnings_by_type'][:5],
                'best_programs': analytics['best_programs'][:5],
                'platform_earnings': analytics['earnings_by_platform']
            }
        })
    except Exception as e:
        return jsonify({'success': False, 'error': str(e)})

@app.route('/api/programs/search', methods=['POST'])
def search_programs():
    """Search for bug bounty programs"""
    try:
        data = request.json
        query = data.get('query', '')
        platform = data.get('platform', 'all')
        
        programs = []
        
        # Search across platforms
        if platform in ['all', 'hackerone']:
            # In production, this would use actual API
            programs.extend([
                {
                    'platform': 'hackerone',
                    'handle': 'security',
                    'name': 'Security',
                    'bounty_range': '$100 - $10,000',
                    'managed': True
                }
            ])
        
        if platform in ['all', 'bugcrowd']:
            # In production, this would use actual API
            programs.extend([
                {
                    'platform': 'bugcrowd',
                    'handle': 'example',
                    'name': 'Example Corp',
                    'bounty_range': '$50 - $5,000',
                    'managed': False
                }
            ])
        
        # Calculate ROI scores
        scored_programs = revenue_maximizer.prioritize_targets(programs)
        
        return jsonify({
            'success': True,
            'programs': scored_programs
        })
    except Exception as e:
        return jsonify({'success': False, 'error': str(e)})

@app.route('/api/hunt/start', methods=['POST'])
def start_hunt():
    """Start a new bug bounty hunt"""
    try:
        data = request.json
        target = data.get('target')
        platform = data.get('platform')
        program = data.get('program')
        config = data.get('config', {})
        
        if not target:
            return jsonify({'success': False, 'error': 'Target is required'})
        
        # Generate hunt ID
        hunt_id = f"hunt_{int(time.time())}"
        
        # Create progress tracker
        progress = HuntProgress(hunt_id)
        active_hunts[hunt_id] = progress
        
        # Start hunt in background thread
        thread = threading.Thread(
            target=run_hunt_background,
            args=(hunt_id, target, platform, program, config)
        )
        thread.daemon = True
        thread.start()
        
        return jsonify({
            'success': True,
            'hunt_id': hunt_id,
            'message': f'Hunt started for {target}'
        })
        
    except Exception as e:
        return jsonify({'success': False, 'error': str(e)})

@app.route('/api/hunt/<hunt_id>/status')
def hunt_status(hunt_id):
    """Get hunt status and progress"""
    if hunt_id not in active_hunts:
        return jsonify({'success': False, 'error': 'Hunt not found'})
    
    progress = active_hunts[hunt_id]
    
    return jsonify({
        'success': True,
        'status': progress.status,
        'phase': progress.phase,
        'progress': progress.progress,
        'findings_count': len(progress.findings),
        'duration': (datetime.now() - progress.start_time).total_seconds(),
        'logs': progress.logs[-20:]  # Last 20 log entries
    })

@app.route('/api/hunt/<hunt_id>/stop', methods=['POST'])
def stop_hunt(hunt_id):
    """Stop an active hunt"""
    if hunt_id in active_hunts:
        active_hunts[hunt_id].status = 'stopped'
        return jsonify({'success': True, 'message': 'Hunt stopped'})
    return jsonify({'success': False, 'error': 'Hunt not found'})

@app.route('/api/findings')
def get_findings():
    """Get all findings with filtering"""
    try:
        # Get filters from query params
        severity = request.args.get('severity')
        vuln_type = request.args.get('type')
        days = int(request.args.get('days', 30))
        
        conn = sqlite3.connect(revenue_maximizer.db_path)
        cursor = conn.cursor()
        
        query = """
            SELECT * FROM earnings 
            WHERE date_submitted > date('now', '-' || ? || ' days')
        """
        params = [days]
        
        if severity:
            query += " AND severity = ?"
            params.append(severity)
            
        if vuln_type:
            query += " AND vulnerability_type = ?"
            params.append(vuln_type)
            
        query += " ORDER BY date_submitted DESC"
        
        cursor.execute(query, params)
        
        findings = []
        for row in cursor.fetchall():
            findings.append({
                'id': row[0],
                'platform': row[1],
                'program': row[2],
                'type': row[3],
                'severity': row[4],
                'amount': row[5],
                'status': row[9],
                'date': row[7],
                'duplicate': bool(row[12])
            })
        
        conn.close()
        
        return jsonify({
            'success': True,
            'findings': findings,
            'total': len(findings)
        })
        
    except Exception as e:
        return jsonify({'success': False, 'error': str(e)})

@app.route('/api/reports/<hunt_id>')
def get_reports(hunt_id):
    """Get reports for a specific hunt"""
    try:
        if hunt_id not in active_hunts:
            return jsonify({'success': False, 'error': 'Hunt not found'})
        
        progress = active_hunts[hunt_id]
        if not progress.workspace:
            return jsonify({'success': False, 'error': 'No workspace found'})
        
        workspace = Path(progress.workspace)
        reports = []
        
        # Find all report files
        for report_file in workspace.glob("*.md"):
            reports.append({
                'name': report_file.name,
                'type': 'markdown',
                'size': report_file.stat().st_size,
                'path': str(report_file)
            })
        
        for report_file in workspace.glob("*.html"):
            reports.append({
                'name': report_file.name,
                'type': 'html',
                'size': report_file.stat().st_size,
                'path': str(report_file)
            })
        
        return jsonify({
            'success': True,
            'reports': reports
        })
        
    except Exception as e:
        return jsonify({'success': False, 'error': str(e)})

@app.route('/api/reports/download/<path:filepath>')
def download_report(filepath):
    """Download a specific report"""
    try:
        # Validate file path for security
        filepath = Path(filepath)
        if not filepath.exists():
            return jsonify({'success': False, 'error': 'File not found'})
        
        return send_file(filepath, as_attachment=True)
        
    except Exception as e:
        return jsonify({'success': False, 'error': str(e)})

@app.route('/api/monitoring/targets')
def get_monitored_targets():
    """Get all monitored targets"""
    try:
        conn = sqlite3.connect(continuous_monitor.db_path)
        cursor = conn.cursor()
        
        cursor.execute("""
            SELECT target, platform, program, check_frequency_hours, 
                   last_checked, enabled, priority
            FROM monitored_targets
            ORDER BY priority DESC
        """)
        
        targets = []
        for row in cursor.fetchall():
            targets.append({
                'target': row[0],
                'platform': row[1],
                'program': row[2],
                'frequency_hours': row[3],
                'last_checked': row[4],
                'enabled': bool(row[5]),
                'priority': row[6]
            })
        
        conn.close()
        
        return jsonify({
            'success': True,
            'targets': targets
        })
        
    except Exception as e:
        return jsonify({'success': False, 'error': str(e)})

@app.route('/api/monitoring/add', methods=['POST'])
def add_monitoring_target():
    """Add a target for continuous monitoring"""
    try:
        data = request.json
        target = data.get('target')
        platform = data.get('platform')
        program = data.get('program')
        frequency = data.get('frequency_hours', 24)
        
        continuous_monitor.add_monitoring_target(target, platform, program, frequency)
        
        return jsonify({
            'success': True,
            'message': f'Added {target} to monitoring'
        })
        
    except Exception as e:
        return jsonify({'success': False, 'error': str(e)})

@app.route('/api/monitoring/changes')
def get_recent_changes():
    """Get recent changes detected by monitoring"""
    try:
        hours = int(request.args.get('hours', 24))
        changes = continuous_monitor.get_recent_changes(hours)
        
        return jsonify({
            'success': True,
            'changes': changes,
            'total': len(changes)
        })
        
    except Exception as e:
        return jsonify({'success': False, 'error': str(e)})

@app.route('/api/revenue/analytics')
def revenue_analytics():
    """Get detailed revenue analytics"""
    try:
        analytics = revenue_maximizer.get_earnings_analytics()
        schedule = revenue_maximizer.optimize_testing_schedule()
        
        # Get monthly trend
        conn = sqlite3.connect(revenue_maximizer.db_path)
        cursor = conn.cursor()
        
        cursor.execute("""
            SELECT 
                strftime('%Y-%m', date_submitted) as month,
                SUM(amount) as total,
                COUNT(*) as count
            FROM earnings
            WHERE status = 'paid'
            GROUP BY month
            ORDER BY month DESC
            LIMIT 12
        """)
        
        monthly_trend = []
        for row in cursor.fetchall():
            monthly_trend.append({
                'month': row[0],
                'earnings': row[1] or 0,
                'submissions': row[2]
            })
        
        conn.close()
        
        return jsonify({
            'success': True,
            'analytics': analytics,
            'schedule': schedule,
            'monthly_trend': monthly_trend
        })
        
    except Exception as e:
        return jsonify({'success': False, 'error': str(e)})

@app.route('/api/settings')
def get_settings():
    """Get application settings"""
    try:
        # Load configuration
        config_path = Path('config.yaml')
        if config_path.exists():
            import yaml
            with open(config_path) as f:
                config = yaml.safe_load(f)
        else:
            config = {}
        
        # Check API keys
        has_openai = bool(os.environ.get('OPENAI_API_KEY'))
        has_hackerone = bool(os.environ.get('HACKERONE_API_TOKEN'))
        has_bugcrowd = bool(os.environ.get('BUGCROWD_API_TOKEN'))
        
        return jsonify({
            'success': True,
            'config': config,
            'api_keys': {
                'openai': has_openai,
                'hackerone': has_hackerone,
                'bugcrowd': has_bugcrowd
            }
        })
        
    except Exception as e:
        return jsonify({'success': False, 'error': str(e)})

@app.route('/api/settings', methods=['POST'])
def update_settings():
    """Update application settings"""
    try:
        data = request.json
        config = data.get('config', {})
        
        # Save configuration
        import yaml
        with open('config.yaml', 'w') as f:
            yaml.dump(config, f)
        
        return jsonify({
            'success': True,
            'message': 'Settings updated successfully'
        })
        
    except Exception as e:
        return jsonify({'success': False, 'error': str(e)})

# WebSocket Events

@socketio.on('connect')
def handle_connect():
    """Handle client connection"""
    logger.info(f"Client connected: {request.sid}")
    emit('connected', {'message': 'Connected to Bug Bounty Assistant'})

@socketio.on('disconnect')
def handle_disconnect():
    """Handle client disconnection"""
    logger.info(f"Client disconnected: {request.sid}")

# Background Hunt Runner

def run_hunt_background(hunt_id: str, target: str, platform: str, program: str, config: Dict):
    """Run hunt in background thread"""
    global assistant
    
    try:
        progress = active_hunts[hunt_id]
        progress.status = 'running'
        
        # Initialize assistant if needed
        api_key = os.environ.get('OPENAI_API_KEY')
        if not api_key:
            progress.update('error', 0, 'OpenAI API key not configured')
            progress.status = 'error'
            return
        
        # Create assistant instance for this hunt
        assistant = EnhancedBugBountyAssistantV3(api_key, config)
        
        # Custom logging to capture progress
        class ProgressHandler(logging.Handler):
            def emit(self, record):
                message = self.format(record)
                progress.logs.append({
                    'timestamp': datetime.now().isoformat(),
                    'level': record.levelname,
                    'message': message
                })
                
                # Emit via WebSocket
                socketio.emit('hunt_log', {
                    'hunt_id': hunt_id,
                    'level': record.levelname,
                    'message': message
                })
        
        # Add progress handler to logger
        handler = ProgressHandler()
        handler.setFormatter(logging.Formatter('%(message)s'))
        logger.addHandler(handler)
        
        # Phase 1: Initialization
        progress.update('initialization', 10, f'Starting hunt on {target}')
        assistant.initialize_hunt(target, platform, program)
        progress.workspace = str(assistant.workspace)
        
        # Phase 2: AI Analysis
        progress.update('analysis', 20, 'Analyzing target with AI...')
        analysis = assistant.ai_target_analysis()
        
        # Phase 3: Reconnaissance
        progress.update('reconnaissance', 40, 'Performing reconnaissance...')
        recon_data = assistant.intelligent_recon()
        
        # Phase 4: Vulnerability Hunting
        progress.update('vulnerability_hunting', 60, 'Hunting for vulnerabilities...')
        findings = assistant.ai_vulnerability_hunting(recon_data)
        progress.findings = findings
        
        # Phase 5: Chain Detection
        progress.update('chain_analysis', 80, 'Analyzing vulnerability chains...')
        chains = assistant.ai_chain_detection()
        
        # Phase 6: Report Generation
        progress.update('reporting', 90, 'Generating reports...')
        reports = assistant.generate_reports()
        
        # Phase 7: Submission Processing
        progress.update('submission', 95, 'Processing submissions...')
        submission_results = assistant.auto_submit_findings()
        
        # Complete
        progress.update('complete', 100, 'Hunt completed successfully!')
        progress.status = 'completed'
        
        # Remove progress handler
        logger.removeHandler(handler)
        
        # Emit completion event
        socketio.emit('hunt_complete', {
            'hunt_id': hunt_id,
            'findings_count': len(findings),
            'chains_count': len(chains),
            'workspace': progress.workspace
        })
        
    except Exception as e:
        progress = active_hunts.get(hunt_id)
        if progress:
            progress.update('error', progress.progress, f'Error: {str(e)}')
            progress.status = 'error'
        
        logger.error(f"Hunt {hunt_id} failed: {e}")
        
        socketio.emit('hunt_error', {
            'hunt_id': hunt_id,
            'error': str(e)
        })

# Initialize and run

def initialize_app():
    """Initialize the web application"""
    global platform_integration
    
    # Create required directories
    os.makedirs('templates', exist_ok=True)
    os.makedirs('static', exist_ok=True)
    
    # Initialize platform integration
    platform_integration = PlatformIntegration({})
    
    # Start continuous monitoring
    continuous_monitor.start_monitoring()
    
    logger.info("Bug Bounty Assistant Web App initialized")

if __name__ == '__main__':
    initialize_app()
    socketio.run(app, debug=True, host='0.0.0.0', port=5000)
